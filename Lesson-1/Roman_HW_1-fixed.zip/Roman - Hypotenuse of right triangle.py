from math import sqrt
a = float(input('Enter first cathetus: '))
b = float(input('Enter second cathetus: '))
c = sqrt(a ** 2 + b ** 2)
print('The hypotenuse of given triangle is', c)
