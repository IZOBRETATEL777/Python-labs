a, b, c = map(int, input('Enter three integers in one line: ').split())
s = a + b + c
print('Sum of numbers:', s)
print('Average of numbers:', s / 3)
